import React from 'react';
import { BrowserRouter, NavLink, Routes, Route } from "react-router-dom";
import logo from './assets/images/Logo.JPG';
import './assets/css/App.css';

import Welcome from './components/Welcome';
import Home from './pages/Home';
import About from './pages/about';
import Projects from './pages/projects';
import Contacts from './pages/contacts';

function App() {
  return (
    <BrowserRouter>
      <div className="App">
        <header className="App-header">
        <img src={logo} className="ali-logo" alt="logo" />
          <nav>
            <ul>
              <li><NavLink to="/" className="current">Home</NavLink></li>
              <li><NavLink to="/about" className="current">About</NavLink></li>
              <li><NavLink to="/projects" className="current">Projects</NavLink></li>
              <li><NavLink to="/contacts" className="current">Contacts</NavLink></li>
            </ul>
          </nav>
        </header>
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="about" element={<About />} />
          <Route path="projects" element={<Projects />} />
          <Route path="contacts" element={<Contacts />} />
        </Routes>
      </div>
      </BrowserRouter>
  );
}

export default App;
