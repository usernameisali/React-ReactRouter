export default function Contacts() {
    return (
      <main style={{ padding: "1rem 0" }}>
        <h2>Contacts</h2>
        <p>Feel free to Contact me +1 123 123456</p>
      </main>
    );
  }
  